import React from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";

const Dashboard = () => {
  return (
    <ScrollView className="flex-1 px-5 py-4 bg-gray-50">
      {/* TITLE */}
      <Text className="text-2xl font-bold text-gray-900 mb-1">
        Dashboard & Analytics
      </Text>
      <Text className="text-gray-500 mb-6">
        Overview of your recruitment activities and performance metrics
      </Text>

      {/* TOP CARDS */}
      <View className="flex-row flex-wrap justify-between mb-6">
        <MetricCard label="Active Job Posts" value="12" icon="briefcase-outline" trend="+2 this month" />
        <MetricCard label="Total Applicants" value="247" icon="people-outline" trend="+18% this week" />
        <MetricCard label="Profile Views" value="1,834" icon="eye-outline" trend="+12% this month" />
        <MetricCard label="Success Rate" value="68%" icon="trending-up-outline" trend="+5% from last month" />
      </View>

      {/* TABS */}
      <View className="flex-row bg-gray-200 rounded-full mb-4">
        <DashboardTab label="Saved" active />
        <DashboardTab label="Selected" />
        <DashboardTab label="Pending" />
        <DashboardTab label="Archived" />
      </View>

      {/* CANDIDATE LIST */}
      <CandidateItem
        initials="JDC"
        name="Juan Dela Cruz"
        role="Software Engineer"
        savedAgo="Saved 2 days ago"
      />

      <CandidateItem
        initials="MS"
        name="Maria Santos"
        role="Marketing Manager"
        savedAgo="Saved 3 days ago"
      />

      <CandidateItem
        initials="PR"
        name="Pedro Reyes"
        role="Graphic Designer"
        savedAgo="Saved 5 days ago"
      />
    </ScrollView>
  );
};

export default Dashboard;

/* COMPONENTS */

type MetricCardProps = {
  label: string;
  value: string;
  icon: string;
  trend: string;
};

const MetricCard = ({ label, value, icon, trend }: MetricCardProps) => (
  <View className="w-[48%] bg-white rounded-xl p-4 mb-3 shadow-sm">
    <View className="flex-row justify-between items-center mb-2">
      <Text className="text-gray-500">{label}</Text>
      <Ionicons name={icon as any} size={22} color="#2563eb" />
    </View>
    <Text className="text-2xl font-bold text-gray-900">{value}</Text>
    <Text className="text-green-600 text-sm mt-1">{trend}</Text>
  </View>
);

type DashboardTabProps = {
  label: string;
  active?: boolean;
};

const DashboardTab = ({ label, active = false }: DashboardTabProps) => (
  <TouchableOpacity
    className={`flex-1 py-2 rounded-full ${active ? "bg-white" : ""}`}
  >
    <Text
      className={`text-center font-semibold ${
        active ? "text-blue-600" : "text-gray-600"
      }`}
    >
      {label}
    </Text>
  </TouchableOpacity>
);

type CandidateItemProps = {
  initials: string;
  name: string;
  role: string;
  savedAgo: string;
};

const CandidateItem = ({
  initials,
  name,
  role,
  savedAgo,
}: CandidateItemProps) => (
  <View className="bg-white rounded-2xl p-4 mb-3 shadow-sm flex-row items-center">
    <View className="w-12 h-12 rounded-full bg-blue-600 justify-center items-center">
      <Text className="text-white font-bold">{initials}</Text>
    </View>

    <View className="flex-1 ml-4">
      <Text className="font-bold text-gray-900">{name}</Text>
      <Text className="text-gray-500">{role}</Text>
      <Text className="text-gray-400 text-xs">{savedAgo}</Text>
    </View>

    <View className="flex-row gap-2">
      <TouchableOpacity className="px-3 py-2 bg-blue-600 rounded-lg">
        <Text className="text-white text-sm">View Profile</Text>
      </TouchableOpacity>

      <TouchableOpacity className="px-3 py-2 bg-gray-200 rounded-lg">
        <Text className="text-gray-800 text-sm">Contact</Text>
      </TouchableOpacity>
    </View>
  </View>
);