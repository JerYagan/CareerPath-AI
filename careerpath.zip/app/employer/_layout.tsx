import React, { useState } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { Stack } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import EmployerSidebar from "@/components/features/employer/EmployerSidebar";

const EmployerLayout = () => {
  const [sidebarVisible, setSidebarVisible] = useState(false);

  return (
    <>
      <EmployerSidebar
        visible={sidebarVisible}
        onClose={() => setSidebarVisible(false)}
      />

      <View className="flex-1 bg-white">
        {/* HEADER */}
        <View className="flex-row items-center justify-between px-5 py-4 border-b border-gray-200 bg-white">
          <TouchableOpacity onPress={() => setSidebarVisible(true)}>
            <Ionicons name="menu-outline" size={28} color="#2563eb" />
          </TouchableOpacity>

          <Text className="text-lg font-semibold text-gray-900">
            Employer Panel
          </Text>

          <TouchableOpacity>
            <Ionicons name="notifications-outline" size={24} color="#2563eb" />
          </TouchableOpacity>
        </View>

        <Stack screenOptions={{ headerShown: false }} />
      </View>
    </>
  );
};

export default EmployerLayout;
