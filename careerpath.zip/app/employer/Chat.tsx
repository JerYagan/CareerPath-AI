import React, { useMemo, useState } from "react";
import { View, Text, ScrollView, TextInput, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import chatThreads from "@/assets/data/employerData/chatThreads.json";

type Thread = {
  id: string;
  candidateId: string;
  name: string;
  lastMessage: string;
  time: string;
};

const Chat = () => {
  const [search, setSearch] = useState("");
  const router = useRouter();

  const threads: Thread[] = chatThreads.threads;

  const filtered = useMemo(() => {
    const term = search.toLowerCase();
    return threads.filter((t) =>
      t.name.toLowerCase().includes(term) ||
      t.lastMessage.toLowerCase().includes(term)
    );
  }, [search]);

  return (
    <ScrollView className="flex-1 px-5 py-4 bg-gray-50">
      <Text className="text-2xl font-bold text-gray-900 mb-2">Messages</Text>

      {/* Search */}
      <View className="flex-row items-center bg-white rounded-full px-4 py-2 mb-4 shadow-sm">
        <Ionicons name="search-outline" size={20} color="#9ca3af" />
        <TextInput
          className="flex-1 ml-2 text-gray-900"
          placeholder="Search messages"
          placeholderTextColor="#9ca3af"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Chat List */}
      {filtered.map((thread) => (
        <TouchableOpacity
          key={thread.id}
          onPress={() => router.push(`./employer/Chat/${thread.id}`)}
          className="bg-white rounded-2xl p-4 mb-3 shadow-sm flex-row justify-between items-center"
        >
          <View className="flex-1">
            <Text className="text-lg font-bold text-gray-900">{thread.name}</Text>
            <Text className="text-gray-500" numberOfLines={1}>
              {thread.lastMessage}
            </Text>
          </View>

          <Text className="text-gray-400 ml-3">{thread.time}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
};

export default Chat;
