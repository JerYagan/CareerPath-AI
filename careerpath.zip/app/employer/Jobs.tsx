import React, { useMemo, useState } from "react";
import { View, Text, ScrollView, TextInput, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import jobsData from "@/assets/data/employerData/jobs.json";

type JobStatus = "Active" | "Closed" | "Draft";

type Job = {
  id: string;
  title: string;
  location: string;
  applicants: number;
  views: number;
  status: JobStatus | string;
  postedAgo: string;
  jobType: string;
  salaryRange: string;
};

const JOBS: Job[] = jobsData.jobs;

const STATUS_FILTERS = [
  { key: "all", label: "All" },
  { key: "active", label: "Active" },
  { key: "draft", label: "Drafts" },
  { key: "closed", label: "Closed" },
] as const;

type StatusFilterKey = (typeof STATUS_FILTERS)[number]["key"];

const Jobs = () => {
  const [search, setSearch] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<StatusFilterKey>("all");

  const filteredJobs = useMemo(() => {
    const term = search.toLowerCase().trim();

    return JOBS.filter((job) => {
      const matchesSearch =
        term.length === 0 ||
        job.title.toLowerCase().includes(term) ||
        job.location.toLowerCase().includes(term) ||
        job.id.toLowerCase().includes(term);

      const matchesStatus =
        statusFilter === "all" ||
        (statusFilter === "active" && job.status === "Active") ||
        (statusFilter === "draft" && job.status === "Draft") ||
        (statusFilter === "closed" && job.status === "Closed");

      return matchesSearch && matchesStatus;
    });
  }, [search, statusFilter]);

  return (
    <ScrollView className="flex-1 px-5 py-4 bg-gray-50">
      {/* Header text */}
      <Text className="text-2xl font-bold text-gray-900 mb-1">
        Job Posts
      </Text>
      <Text className="text-gray-500 mb-4">
        Manage and track all opportunities you've published.
      </Text>

      {/* Search bar */}
      <View className="flex-row items-center bg-white rounded-full px-4 py-2 mb-3 shadow-sm">
        <Ionicons name="search-outline" size={20} color="#9ca3af" />
        <TextInput
          className="flex-1 ml-2 text-gray-900"
          placeholder="Search job title, location, or job ID"
          placeholderTextColor="#9ca3af"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Status filters */}
      <View className="flex-row mb-4">
        {STATUS_FILTERS.map((filter) => {
          const isActive = statusFilter === filter.key;
          return (
            <TouchableOpacity
              key={filter.key}
              onPress={() => setStatusFilter(filter.key)}
              className={`px-3 py-2 mr-2 rounded-full border ${
                isActive ? "bg-blue-600 border-blue-600" : "bg-white border-gray-200"
              }`}
            >
              <Text
                className={`font-medium ${
                  isActive ? "text-white" : "text-gray-700"
                }`}
              >
                {filter.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Job list */}
      {filteredJobs.map((job) => (
        <JobCard key={job.id} job={job} />
      ))}

      {/* Empty state */}
      {filteredJobs.length === 0 && (
        <View className="mt-10 items-center">
          <Ionicons name="briefcase-outline" size={40} color="#9ca3af" />
          <Text className="mt-3 font-semibold text-gray-700">
            No jobs found
          </Text>
          <Text className="text-gray-500 mt-1 text-center">
            Try adjusting your search or filters to see more job posts.
          </Text>
        </View>
      )}
    </ScrollView>
  );
};

export default Jobs;

type JobCardProps = {
  job: Job;
};

const JobCard = ({ job }: JobCardProps) => {
  const router = useRouter();

  return (
    <View className="bg-white rounded-2xl p-4 mb-3 shadow-sm">
      {/* ...other content */}

      <View className="flex-row justify-between items-center mt-2">
        <Text className="text-gray-400">{job.postedAgo}</Text>

        <View className="flex-row">
          <TouchableOpacity
            onPress={() => router.push(`./${job.id}`)}
            className="px-3 py-2 rounded-lg bg-gray-100 mr-2"
          >
            <Text className="text-gray-800">View details</Text>
          </TouchableOpacity>

          <TouchableOpacity className="px-3 py-2 rounded-lg bg-blue-600">
            <Text className="text-white">Edit</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const getStatusStyles = (status: JobStatus) => {
  switch (status) {
    case "Active":
      return {
        bgClass: "bg-green-100",
        textClass: "text-green-700",
      };
    case "Closed":
      return {
        bgClass: "bg-red-100",
        textClass: "text-red-700",
      };
    case "Draft":
      return {
        bgClass: "bg-yellow-100",
        textClass: "text-yellow-700",
      };
    default:
      return {
        bgClass: "bg-gray-100",
        textClass: "text-gray-700",
      };
  }
};
