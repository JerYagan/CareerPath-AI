import React, { useState, useMemo } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { useRouter, router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import candidatesData from "@/assets/data/employerData/candidates.json";

type Candidate = {
  id: string;
  name: string;
  role: string;
  skills: string[];
  experience: string;
  location: string;
  email: string;
  status: string;
};

const STATUS_FILTERS = [
  "All",
  "Available",
  "Open to Work",
  "Not Available",
] as const;

type FilterKey = (typeof STATUS_FILTERS)[number];

const FindCandidates = () => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterKey>("All");

  const candidates: Candidate[] = candidatesData.candidates;

  const filtered = useMemo(() => {
    const term = search.toLowerCase();

    return candidates.filter((c) => {
      const matchesSearch =
        c.name.toLowerCase().includes(term) ||
        c.role.toLowerCase().includes(term) ||
        c.email.toLowerCase().includes(term) ||
        c.skills.some((s) => s.toLowerCase().includes(term));

      const matchesFilter = filter === "All" || c.status === filter;

      return matchesSearch && matchesFilter;
    });
  }, [search, filter]);

  return (
    <ScrollView className="flex-1 px-5 py-4 bg-gray-50">
      {/* Title */}
      <Text className="text-2xl font-bold text-gray-900 mb-1">
        Find Candidates
      </Text>
      <Text className="text-gray-500 mb-4">
        Discover and connect with potential talent.
      </Text>

      {/* Search Bar */}
      <View className="flex-row items-center bg-white rounded-full px-4 py-2 mb-3 shadow-sm">
        <Ionicons name="search-outline" size={20} color="#9ca3af" />
        <TextInput
          className="flex-1 ml-2 text-gray-900"
          placeholder="Search name, skills, or role"
          placeholderTextColor="#9ca3af"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Status Filters */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mb-4">
        <View className="flex-row">
          {STATUS_FILTERS.map((status) => {
            const isActive = filter === status;
            return (
              <TouchableOpacity
                key={status}
                onPress={() => setFilter(status)}
                className={`px-4 py-2 rounded-full mr-2 border ${
                  isActive
                    ? "bg-blue-600 border-blue-600"
                    : "bg-white border-gray-200"
                }`}
              >
                <Text
                  className={`font-medium ${
                    isActive ? "text-white" : "text-gray-700"
                  }`}
                >
                  {status}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>

      {/* Candidate List */}
      {filtered.map((item) => (
        <CandidateCard key={item.id} item={item} />
      ))}

      {/* Empty */}
      {filtered.length === 0 && (
        <View className="mt-10 items-center">
          <Ionicons name="people-outline" size={40} color="#9ca3af" />
          <Text className="mt-3 font-semibold text-gray-700">
            No candidates found
          </Text>
          <Text className="text-gray-500 mt-1 text-center">
            Try adjusting your search or filters.
          </Text>
        </View>
      )}
    </ScrollView>
  );
};

export default FindCandidates;

const CandidateCard = ({ item }: { item: Candidate }) => {
  const statusStyles = getStatusColors(item.status);

  return (
    <View className="bg-white rounded-2xl p-4 mb-3 shadow-sm">
      {/* NAME */}
      <Text className="font-bold text-gray-900 text-lg">{item.name}</Text>
      <Text className="text-gray-500">{item.email}</Text>

      {/* ROLE */}
      <Text className="text-gray-700 mt-2 font-medium">{item.role}</Text>
      <Text className="text-gray-500">{item.experience} experience</Text>

      {/* LOCATION */}
      <Text className="text-gray-500 mt-1">{item.location}</Text>

      {/* Skills */}
      <View className="flex-row flex-wrap mt-3">
        {item.skills.map((skill) => (
          <View
            key={skill}
            className="px-3 py-1 bg-gray-100 rounded-full mr-2 mb-2"
          >
            <Text className="text-gray-700 text-sm">{skill}</Text>
          </View>
        ))}
      </View>

      {/* Status */}
      <View className={`self-start mt-2 px-3 py-1 rounded-full ${statusStyles.bgClass}`}>
        <Text className={`font-medium ${statusStyles.textClass}`}>
          {item.status}
        </Text>
      </View>

      {/* Buttons */}
      <View className="flex-row justify-end mt-4 gap-2">
        <TouchableOpacity className="px-3 py-2 bg-gray-100 rounded-lg">
          <Text className="text-gray-800">Save</Text>
        </TouchableOpacity>

        <TouchableOpacity className="px-3 py-2 bg-blue-600 rounded-lg" onPress={() => router.push(`./employer/Candidates/${item.id}`)}>
          <Text className="text-white">Contact</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const getStatusColors = (status: string) => {
  switch (status) {
    case "Available":
      return { bgClass: "bg-green-100", textClass: "text-green-700" };
    case "Open to Work":
      return { bgClass: "bg-blue-100", textClass: "text-blue-700" };
    case "Not Available":
      return { bgClass: "bg-red-100", textClass: "text-red-700" };
    default:
      return { bgClass: "bg-gray-100", textClass: "text-gray-700" };
  }
};