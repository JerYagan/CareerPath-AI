import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import chatThreads from "@/assets/data/employerData/chatThreads.json";

type Message = {
  id: string;
  sender: "me" | "them";
  text: string;
  time: string;
};

const ChatRoom = () => {
  const { id } = useLocalSearchParams();
  const router = useRouter();

  const thread = chatThreads.threads.find((t) => t.id === id);

  // TEMPORARY local messages (replace with backend)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "m1",
      sender: "them",
      text: "Hi! Is the position still open?",
      time: "10:40 AM",
    },
    {
      id: "m2",
      sender: "me",
      text: "Yes, still open. Would you like to schedule an interview?",
      time: "10:42 AM",
    }
  ]);

  const [text, setText] = useState("");

  const sendMessage = () => {
    if (!text.trim()) return;

    const newMessage: Message = {
      id: Math.random().toString(),
      sender: "me",
      text,
      time: "Now",
    };

    setMessages([...messages, newMessage]);
    setText("");
  };

  if (!thread) {
    return (
      <View className="flex-1 justify-center items-center">
        <Text className="text-gray-500">Thread not found</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-gray-50"
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      {/* HEADER */}
      <View className="flex-row items-center px-4 py-3 border-b border-gray-200 bg-white">
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#2563eb" />
        </TouchableOpacity>
        <Text className="text-lg font-bold ml-3 text-gray-900">{thread.name}</Text>
      </View>

      {/* MESSAGES */}
      <ScrollView className="flex-1 px-4 py-3">
        {messages.map((msg) => (
          <View
            key={msg.id}
            className={`max-w-[75%] p-3 rounded-xl mb-3 ${
              msg.sender === "me"
                ? "bg-blue-600 ml-auto"
                : "bg-gray-200"
            }`}
          >
            <Text
              className={`${
                msg.sender === "me" ? "text-white" : "text-gray-900"
              }`}
            >
              {msg.text}
            </Text>
            <Text
              className={`text-xs mt-1 ${
                msg.sender === "me" ? "text-blue-200" : "text-gray-500"
              }`}
            >
              {msg.time}
            </Text>
          </View>
        ))}
      </ScrollView>

      {/* INPUT BAR */}
      <View className="flex-row items-center px-4 py-3 bg-white border-t border-gray-200">
        <TextInput
          className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-gray-900 mr-2"
          placeholder="Type a message..."
          placeholderTextColor="#9ca3af"
          value={text}
          onChangeText={setText}
        />

        <TouchableOpacity
          onPress={sendMessage}
          className="bg-blue-600 rounded-full p-3"
        >
          <Ionicons name="send" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default ChatRoom;