import React from 'react'

const GoogleLogin = () => {
  return (
    <div>GoogleLogin</div>
  )
}

export default GoogleLogin