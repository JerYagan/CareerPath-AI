import React from 'react'
import { View } from 'react-native'

const HorizontalFilters = () => {
  return (
    <View>HorizontalFilters</View>
  )
}

export default HorizontalFilters